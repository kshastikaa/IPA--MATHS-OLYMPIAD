# IPA Maths Olympiad Grade 3 – Maths Olympiad Quiz
Static web app (no backend, no database). Everything is in `index.html`.

## Put it on GitHub Pages
1. Create a new GitHub repo (e.g. `cmo-quiz`) and upload `index.html` and `README.md`.
2. Repo → Settings → Pages → Source: *Deploy from a branch* → `main` / `(root)` → Save.
3. Open `https://<your-username>.github.io/cmo-quiz/` (HTTPS is needed for camera access).

Run locally: `python -m http.server 8000` then open http://localhost:8000
